package com.example.peiandsky;

public interface PokeType {
	int danpai=1;
	int duipai=2;
	int sanzhang=3;
	int sandaiyi=4;
	int danshun=5;
	int shuangshun=6;
	int sanshun=7;
	int feiji=8;
	int sidaier=9;
	int zhadan=10;
	int huojian=11;
	int error=12;
	
	int dirH=0;
	int dirV=1;
}
