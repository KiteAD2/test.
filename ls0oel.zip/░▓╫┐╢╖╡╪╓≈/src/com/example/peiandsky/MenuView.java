package com.example.peiandsky;

import com.example.peiandsky.R;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Toast;

public class MenuView extends SurfaceView implements SurfaceHolder.Callback,
		OnTouchListener {
	private DDZ ddz;
	SurfaceHolder holder;
	Canvas canvas;
	boolean threadFlag = true;
	Bitmap back;

	private int x = 420;
	private int y = 215;
	private Bitmap[] menuItems;

	public MenuView(Context context, DDZ ddz) {
		super(context);
		this.ddz = ddz;
		menuItems = new Bitmap[2];
		holder = getHolder();
		back = BitmapFactory
				.decodeResource(ddz.getResources(), R.drawable.backgroundori);
		menuItems[0] = BitmapFactory.decodeResource(ddz.getResources(),
				R.drawable.play);
		
		menuItems[1] = BitmapFactory.decodeResource(ddz.getResources(),
				R.drawable.quit);
		// for(int i=0;i<menuItems.length;i++)
		// {
		// menuItems[0]=BitmapFactory.decodeFile("menu"+(i+1)+".png");
		// }

		this.getHolder().addCallback(this);
		this.setOnTouchListener(this);
	}

	Thread menuThread = new Thread() {
		@Override
		public void run() {

			while (threadFlag) {
				try {
					canvas = holder.lockCanvas();
					synchronized (this) {
						onDraw(canvas);
					}
					// System.out.println("menuThread");
				} finally {
					holder.unlockCanvasAndPost(canvas);
				}
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

	};

	@Override
	protected void onDraw(Canvas canvas) {
		Paint paint = new Paint();
		canvas.drawBitmap(back, 0, 0, paint);
		for(int i=0;i<menuItems.length;i++)
			canvas.drawBitmap(menuItems[i], x+180*i, y , paint);
		// paint.setColor(Color.WHITE);
		// paint.setTextSize(32);
		// canvas.drawText("��ʼ��Ϸ", 158, 91, paint);
		// canvas.drawText("��Ϸ����", 158, 121, paint);
		// canvas.drawText("������Ϸ", 158, 151, paint);
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {

	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		threadFlag = true;
		menuThread.start();
		System.out.println("surfaceCreated");
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		threadFlag = false;
		boolean retry = true;
		while (retry) {// ѭ��
			try {
				menuThread.join();// �ȴ��߳̽���
				retry = false;// ֹͣѭ��
			} catch (InterruptedException e) {
			}// ���ϵ�ѭ����ֱ��ˢ֡�߳̽���
		}
	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		int ex = (int) event.getX();
		int ey = (int) event.getY();
		System.out.println(event.getX() + "," + event.getY());
		int selectIndex = -1;
		for(int i=0;i<menuItems.length;i++){
		if (Poke.inRect(ex, ey, x+5+180*i, y, 155, 160)) {
			selectIndex =i;
		}
				}
		switch (selectIndex) {
		case 0:
			ddz.handler.sendEmptyMessage(DDZ.GAME);
			break;
		
		case 1:
						ddz.finish();
			break;
		}
		return super.onTouchEvent(event);
	}

}
